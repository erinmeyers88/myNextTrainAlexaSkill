'use strict';
var Alexa = require('alexa-sdk');
var xml2js = require('xml2js');
var parser = new xml2js.Parser();
var concat = require('concat-stream');
var http = require('http');

var APP_ID = 'amzn1.ask.skill.c8cbde58-d656-403d-ba44-85675fa00b95';
var SKILL_NAME = 'UTA Tracker';

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('GetNextTrain');
    },
    'GetNextTrainIntent': function () {
        this.emit('GetNextTrain');
    },
    'GetNextTrain': function () {

        var self = this;

        // var options = {
        //     path: 'http://api.rideuta.com/SIRI/SIRI.svc/StopMonitor?stopid=801163&minutesout=100&onwardcalls=true&filterroute=750&usertoken=URCONBJBKGE'
        // };
        //
        // var options = {
        //     host: 'http://api.rideuta.com',
        //     port: 80,
        //     path: '/SIRI/SIRI.svc/StopMonitor?stopid=801163&minutesout=100&onwardcalls=true&filterroute=750&usertoken=URCONBJBKGE',
        //     agent: false
        // };

        // var options = {
        //     host: 'http://swapi.co',
        //     path: '/api/people/1/'
        // };


        // http.get('http://api.rideuta.com/SIRI/SIRI.svc/StopMonitor?stopid=801163&minutesout=100&onwardcalls=true&filterroute=750&usertoken=URCONBJBKGE', function(res){
        //     var body = '';
        //
        //     res.on('data', function(data){
        //         body += data;
        //     });
        //
        //     res.on('end', function(){
        //
        //         var json = xml2json(body);
        //         var result = JSON.parse(json);
        //
        //         self.emit(':tellWithCard', result.Siri.ResponseTimeStamp, SKILL_NAME, 'card stuff');
        //
        //     });
        //
        // });




        parser.on('error', function(err) { console.log('Parser error', err); });

        http.get('http://api.rideuta.com/SIRI/SIRI.svc/StopMonitor?stopid=801163&minutesout=100&onwardcalls=true&filterroute=750&usertoken=URCONBJBKGE', function(resp) {
            resp.on('error', function(err) {
                console.log('Error while reading', err);
            });
            resp.pipe(concat(function(buffer) {
                var str = buffer.toString();
                parser.parseString(str, function(err, result) {
                    console.log('RESULT: ', JSON.stringify(result.Siri.StopMonitoringDelivery[0].MonitoredStopVisit[0].MonitoredVehicleJourney[0].DirectionRef[0]));
                    var direction = result.Siri.StopMonitoringDelivery[0].MonitoredStopVisit[0].MonitoredVehicleJourney[0].DirectionRef[0];
                    self.emit(':tellWithCard', direction, SKILL_NAME, 'card stuff');
                });
            }));
        });

    },
    'AMAZON.HelpIntent': function () {
        var speechOutput = "You can say get my next train, or, you can say exit... What can I help you with?";
        var reprompt = "What can I help you with?";
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', 'Goodbye!');
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', 'Goodbye!');
    }
};